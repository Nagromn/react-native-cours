// ./src/surfaces/Login.js
import React from "react";
import { View, Text } from "react-native";
export const Login = () => {
    return (
        <View>
            <Text>this will be the login screen</Text>
        </View>
    );
};