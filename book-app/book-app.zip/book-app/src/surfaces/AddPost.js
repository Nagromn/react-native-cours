import React from "react";
import { View, Text } from "react-native";
export const AddPost = () => {
  return (
    <View>
      <Text>this will be the AddPost screen</Text>
    </View>
  );
};