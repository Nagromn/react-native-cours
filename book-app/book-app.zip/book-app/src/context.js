import React from "react";

export const UserListContext = React.createContext(null);
export const ConversationContext = React.createContext(null);