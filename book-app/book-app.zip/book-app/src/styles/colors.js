export const colors = {
    black: "#000000",
    grey: "#4E4E4E",
    lightGrey: "#C4C4C4",
    white: "#FFFFFF",
    accentStroke: "#25A0B0",
    mainTheme: "#E1F6F4",
    pink: "#F5C8C6",
    accentLines: "#EEF2E2",
  };